from django.conf.urls import url
from appTwo import views

urlpatterns=[url('users/',views.users,name='users'),
url('index/',views.index,name='index'),
]